package com.example.demo.Files;

import java.util.Scanner;

public class Inputhelper {
    private static final Scanner scanner = new Scanner(System.in);

    public static String getInput(String prompt) {
        System.out.print(prompt + " ");
        return scanner.nextLine();
    }

    public static int getIntInput(String prompt) {
        System.out.print(prompt + " ");
        while (!scanner.hasNextInt()) {
            scanner.next();
            System.out.print("Invalid input. " + prompt + " ");
        }
        int input = scanner.nextInt();
        scanner.nextLine();
        return input;
    }

    public static boolean getBoolInput(String prompt) {
        System.out.print(prompt + " ");
        while (!scanner.hasNextBoolean()) {
            scanner.next();
            System.out.print("Invalid input. Please enter true or false. " + prompt + " ");
        }
        boolean input = scanner.nextBoolean();
        scanner.nextLine();
        return input;
    }
}