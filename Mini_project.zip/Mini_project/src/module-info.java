/**
 * 
 */
/**
 * 
 */
module Mini_project {
	requires java.sql;
}